d3 = (function(){
  var d3 = {version: "3.1.9"}; // semver
