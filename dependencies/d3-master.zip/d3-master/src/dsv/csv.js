import "dsv";

d3.csv = d3_dsv(",", "text/csv");
